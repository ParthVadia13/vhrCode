
package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Drivetrain and Motor Test", group = "Testing")
public class alltest extends LinearOpMode {

    // Motor powers
    private static final double MAX_FORWARD_POWER = 0.80;
    private static final double REVERSE_POWER = 0.40;
    private static final double FLYWHEEL_POWER = 0.80;
    private static final double INTAKE_POWER = 0.80;

    // 300-degree servo settings
    private static final double FLOWER_HOME = 0.50;
    private static final double FLOWER_TRAVEL = 300.0 / 300.0;

    private static final double WINDMILL_HOME = 0.05;
    private static final double WINDMILL_STEP = 90.0 / 300.0;

    // Routine timings (seconds)
    private static final double FLOWER_MOVE_TIME = 0.15;
    private static final double WINDMILL_STEP_WAIT = 0.50;
    private static final double WINDMILL_PAUSE = 1.00;
    private static final double WINDMILL_RETURN_TIME = 2.00;

    @Override
    public void runOpMode() {

        // =========================
        // HARDWARE MAPPING
        // =========================

        DcMotor leftMotor =
                hardwareMap.get(DcMotor.class, "leftDrive");

        DcMotor rightMotor =
                hardwareMap.get(DcMotor.class, "rightDrive");

        DcMotor flywheel =
                hardwareMap.get(DcMotor.class, "flywheelMotor");

        DcMotor intake =
                hardwareMap.get(DcMotor.class, "intakeMotor");

        Servo leftFlower =
                hardwareMap.get(Servo.class, "leftServo");

        Servo rightFlower =
                hardwareMap.get(Servo.class, "rightServo");

        Servo windmill =
                hardwareMap.get(Servo.class, "windmillServo");

        // =========================
        // MOTOR CONFIGURATION
        // =========================

        leftMotor.setDirection(DcMotor.Direction.FORWARD);
        rightMotor.setDirection(DcMotor.Direction.REVERSE);
        flywheel.setDirection(DcMotor.Direction.FORWARD);
        intake.setDirection(DcMotor.Direction.FORWARD);

        leftMotor.setZeroPowerBehavior(
                DcMotor.ZeroPowerBehavior.BRAKE);

        rightMotor.setZeroPowerBehavior(
                DcMotor.ZeroPowerBehavior.BRAKE);

        // Stop motors
        leftMotor.setPower(0);
        rightMotor.setPower(0);
        flywheel.setPower(0);
        intake.setPower(0);

        // Initial servo positions
        leftFlower.setPosition(FLOWER_HOME);
        rightFlower.setPosition(FLOWER_HOME);
        windmill.setPosition(WINDMILL_HOME);

        // =========================
        // TOGGLE VARIABLES
        // =========================

        boolean flywheelOn = false;
        boolean intakeOn = false;

        boolean previousX = false;
        boolean previousY = false;

        // =========================
        // FLOWER ROUTINE VARIABLES
        // =========================

        // 0 = idle
        // 1 = moving outward
        // 2 = returning home

        int flowerState = 0;
        int flowerCycles = 0;
        double flowerNextTime = 0;

        // =========================
        // WINDMILL ROUTINE VARIABLES
        // =========================

        // 0 = idle
        // 1 = moving through 90-degree increments
        // 2 = waiting before return
        // 3 = slowly returning home

        int windmillState = 0;
        int windmillStep = 0;

        double windmillNextTime = 0;
        double windmillReturnStartTime = 0;
        double windmillReturnStartPosition = 0;

        // Current commanded windmill position
        double windmillPosition = WINDMILL_HOME;

        // =========================
        // READY
        // =========================

        telemetry.addLine("Robot Ready");
        telemetry.addLine("Triggers = Drive Forward");
        telemetry.addLine("Bumpers = Drive Reverse");
        telemetry.addLine("X = Toggle Flywheel");
        telemetry.addLine("Y = Toggle Intake Motor");
        telemetry.addLine("D-pad Left = Flower Routine");
        telemetry.addLine("D-pad Right = Windmill Routine");
        telemetry.update();

        waitForStart();

        // =========================
        // MAIN LOOP
        // =========================

        while (opModeIsActive()) {

            double now = getRuntime();

            // -------------------------
            // DRIVETRAIN
            // -------------------------

            if (gamepad2.left_bumper) {
                leftMotor.setPower(-REVERSE_POWER);
            } else {
                leftMotor.setPower(
                        gamepad2.left_trigger * MAX_FORWARD_POWER);
            }

            if (gamepad2.right_bumper) {
                rightMotor.setPower(-REVERSE_POWER);
            } else {
                rightMotor.setPower(
                        gamepad2.right_trigger * MAX_FORWARD_POWER);
            }

            // -------------------------
            // X: TOGGLE FLYWHEEL
            // -------------------------

            boolean currentX = gamepad2.x;

            if (currentX && !previousX) {
                flywheelOn = !flywheelOn;
            }

            previousX = currentX;

            flywheel.setPower(
                    flywheelOn ? FLYWHEEL_POWER : 0);

            // -------------------------
            // Y: TOGGLE INTAKE MOTOR
            // -------------------------

            boolean currentY = gamepad2.y;

            if (currentY && !previousY) {
                intakeOn = !intakeOn;
            }

            previousY = currentY;

            intake.setPower(
                    intakeOn ? INTAKE_POWER : 0);

            // =========================
            // D-PAD LEFT: FLOWER ROUTINE
            // =========================

            // Start only when the routine is idle.
            // A new press is required to start it again.
            if (gamepad2.dpad_left && flowerState == 0) {

                flowerCycles = 0;

                // Move both flowers 100 degrees in opposite
                // directions from their home positions.
                leftFlower.setPosition(
                        FLOWER_HOME + FLOWER_TRAVEL);

                rightFlower.setPosition(
                        FLOWER_HOME - FLOWER_TRAVEL);

                flowerState = 1;
                flowerNextTime = now + FLOWER_MOVE_TIME;
            }

            // Advance flower routine without blocking the loop.
            if (flowerState != 0 && now >= flowerNextTime) {

                if (flowerState == 1) {

                    // Return both servos to home.
                    leftFlower.setPosition(FLOWER_HOME);
                    rightFlower.setPosition(FLOWER_HOME);

                    flowerState = 2;
                    flowerNextTime = now + FLOWER_MOVE_TIME;

                } else if (flowerState == 2) {

                    flowerCycles++;

                    if (flowerCycles >= 3) {

                        // Three complete back-and-forth cycles.
                        flowerState = 0;

                    } else {

                        // Start the next cycle.
                        leftFlower.setPosition(
                                FLOWER_HOME + FLOWER_TRAVEL);

                        rightFlower.setPosition(
                                FLOWER_HOME - FLOWER_TRAVEL);

                        flowerState = 1;
                        flowerNextTime =
                                now + FLOWER_MOVE_TIME;
                    }
                }
            }

            // =========================
            // D-PAD RIGHT: WINDMILL
            // =========================

            // Start the routine from its home position.
            if (gamepad2.dpad_right && windmillState == 0) {

                windmillStep = 1;

                // First 90-degree increment
                windmillPosition =
                        WINDMILL_HOME + WINDMILL_STEP;

                windmill.setPosition(windmillPosition);

                windmillState = 1;
                windmillNextTime =
                        now + WINDMILL_STEP_WAIT;
            }

            // State 1: advance in three 90-degree increments.
            if (windmillState == 1 && now >= windmillNextTime) {

                if (windmillStep < 3) {

                    windmillStep++;

                    windmillPosition =
                            WINDMILL_HOME
                            + windmillStep * WINDMILL_STEP;

                    windmill.setPosition(windmillPosition);

                    if (windmillStep == 3) {

                        // Wait one second after the third increment.
                        windmillState = 2;
                        windmillNextTime = now + WINDMILL_PAUSE;

                    } else {

                        windmillNextTime =
                                now + WINDMILL_STEP_WAIT;
                    }
                }
            }

            // State 2: wait, then begin slow return.
            if (windmillState == 2 && now >= windmillNextTime) {

                windmillReturnStartPosition = windmillPosition;
                windmillReturnStartTime = now;

                windmillState = 3;
            }

            // State 3: smoothly change the target position
            // back to home over two seconds.
            if (windmillState == 3) {

                double elapsed =
                        now - windmillReturnStartTime;

                double progress =
                        elapsed / WINDMILL_RETURN_TIME;

                if (progress >= 1.0) {

                    windmillPosition = WINDMILL_HOME;
                    windmill.setPosition(windmillPosition);

                    windmillState = 0;

                } else {

                    // Linear interpolation from the last position
                    // back to the original position.
                    windmillPosition =
                            windmillReturnStartPosition
                            + (WINDMILL_HOME
                            - windmillReturnStartPosition)
                            * progress;

                    windmill.setPosition(windmillPosition);
                }
            }

            // =========================
            // TELEMETRY
            // =========================

            telemetry.addData("Left Drive", leftMotor.getPower());
            telemetry.addData("Right Drive", rightMotor.getPower());

            telemetry.addData("Flywheel",
                    flywheelOn ? "ON" : "OFF");

            telemetry.addData("Intake Motor",
                    intakeOn ? "ON" : "OFF");

            telemetry.addData("Flower Routine",
                    flowerState == 0 ? "IDLE"
                    : "RUNNING - Cycle " + (flowerCycles + 1));

            telemetry.addData("Windmill Routine",
                    windmillState == 0 ? "IDLE"
                    : "STATE " + windmillState);

            telemetry.addData("Windmill Position",
                    windmillPosition);

            telemetry.update();

            // Short loop interval; no long blocking delays.
            sleep(10);
        }

        // =========================
        // STOP ALL MOTORS
        // =========================

        leftMotor.setPower(0);
        rightMotor.setPower(0);
        flywheel.setPower(0);
        intake.setPower(0);
    }
}
