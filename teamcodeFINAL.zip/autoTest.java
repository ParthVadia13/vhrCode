
package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

@Autonomous(name = "Forward Back Auto", group = "Testing")
public class autoTest extends LinearOpMode {

    // =====================================
    // EDITABLE VARIABLES
    // =====================================

    private static final double DRIVE_POWER = 0.40;
    private static final double POWER_BIAS = 0.02;

    private static final double FORWARD_TIME = 1.0;  // seconds
    private static final double BACKWARD_TIME = 0; // seconds

    @Override
    public void runOpMode() {

        // =====================================
        // HARDWARE
        // =====================================

        DcMotor leftMotor =
                hardwareMap.get(DcMotor.class, "leftDrive");

        DcMotor rightMotor =
                hardwareMap.get(DcMotor.class, "rightDrive");

        // Motor directions
        leftMotor.setDirection(DcMotor.Direction.FORWARD);
        rightMotor.setDirection(DcMotor.Direction.REVERSE);

        // Stop motors when power is zero
        leftMotor.setZeroPowerBehavior(
                DcMotor.ZeroPowerBehavior.BRAKE);

        rightMotor.setZeroPowerBehavior(
                DcMotor.ZeroPowerBehavior.BRAKE);

        leftMotor.setPower(0);
        rightMotor.setPower(0);

        telemetry.addLine("Forward / Backward Auto Ready");
        telemetry.addData("Power", DRIVE_POWER);
        telemetry.addData("Forward Time", FORWARD_TIME);
        telemetry.addData("Backward Time", BACKWARD_TIME);
        telemetry.update();

        waitForStart();

        if (opModeIsActive()) {

            // =====================================
            // DRIVE FORWARD
            // =====================================

            leftMotor.setPower(DRIVE_POWER);
            rightMotor.setPower(DRIVE_POWER + POWER_BIAS);

            sleep((long) (FORWARD_TIME * 1000));

            // =====================================
            // DRIVE BACKWARD
            // =====================================

            leftMotor.setPower(-DRIVE_POWER);
            rightMotor.setPower(-DRIVE_POWER  - POWER_BIAS);

            sleep((long) (BACKWARD_TIME * 1000));

            // =====================================
            // STOP
            // =====================================

            leftMotor.setPower(0);
            rightMotor.setPower(0);
        }
    }
}
