package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Jayu TeleOp", group = "Competition")
public class jayuTeleop extends LinearOpMode {

    // =========================
    // DRIVETRAIN SENSITIVITY
    // =========================
    private static final double BASE_POWER = 0.65;
    private static final double POWER_SENSITIVITY_STEP = 0.05;

    // =========================
    // FLYWHEEL SENSITIVITY
    // =========================
    private static final double BASE_FLYWHEEL_POWER = 0.52;
    private static final double FLYWHEEL_SENSITIVITY_STEP = 0.02;

    // =========================
    // SENSITIVITY LEVELS
    // =========================
    private static final int START_SENSITIVITY_LEVEL = 0;
    private static final int MIN_SENSITIVITY_LEVEL = -20;
    private static final int MAX_SENSITIVITY_LEVEL = 20;

    // =========================
    // MOTOR SPEEDS
    // =========================
    private static final double INTAKE_SPEED = 0.70;

    // =========================
    // FLOWER SERVOS
    // =========================
    private static final double FLOWER_HOME = 0.50;
    private static final double FLOWER_TRAVEL = 100.0 / 300.0;
    private static final double FLOWER_MOVE_TIME = 0.15;

    // =========================
    // WINDMILL SERVO
    // =========================
    private static final double WINDMILL_HOME = 0.05;
    private static final double WINDMILL_STEP = 90.0 / 300.0;
    private static final double WINDMILL_STEP_WAIT = 0.50;
    private static final double WINDMILL_PAUSE = 1.00;
    private static final double WINDMILL_RETURN_TIME = 2.00;

    @Override
    public void runOpMode() {

        // =========================
        // HARDWARE
        // =========================
        DcMotor leftDrive = hardwareMap.get(DcMotor.class, "leftDrive");
        DcMotor rightDrive = hardwareMap.get(DcMotor.class, "rightDrive");
        DcMotor flywheelMotor = hardwareMap.get(DcMotor.class, "flywheelMotor");
        DcMotor intakeMotor = hardwareMap.get(DcMotor.class, "intakeMotor");

        Servo sideLeftServo = hardwareMap.get(Servo.class, "leftServo");
        Servo sideRightServo = hardwareMap.get(Servo.class, "rightServo");
        Servo windmillServo = hardwareMap.get(Servo.class, "windmillServo");

        // =========================
        // MOTOR CONFIGURATION
        // =========================
        leftDrive.setDirection(DcMotor.Direction.FORWARD);
        rightDrive.setDirection(DcMotor.Direction.REVERSE);

        flywheelMotor.setDirection(DcMotor.Direction.FORWARD);
        intakeMotor.setDirection(DcMotor.Direction.FORWARD);

        leftDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rightDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // =========================
        // INITIAL SERVO POSITIONS
        // =========================
        sideLeftServo.setPosition(FLOWER_HOME);
        sideRightServo.setPosition(FLOWER_HOME);
        windmillServo.setPosition(WINDMILL_HOME);

        // =========================
        // VARIABLES
        // =========================
        boolean intakeOn = false;
        boolean flywheelOn = false;

        int driveSensitivity = START_SENSITIVITY_LEVEL;
        int flywheelSensitivity = START_SENSITIVITY_LEVEL;

        // Button previous states
        boolean previousA = false;
        boolean previousRB = false;
        boolean previousB = false;

        boolean previousDpadLeft = false;
        boolean previousDpadRight = false;
        boolean previousDpadUp = false;
        boolean previousDpadDown = false;

        // Trigger previous states
        boolean previousRightTrigger = false;
        boolean previousLeftTrigger = false;

        // =========================
        // FLOWER DANCE VARIABLES
        // =========================
        int danceState = 0;
        int danceCycles = 0;
        long danceTimer = 0;

        // =========================
        // WINDMILL VARIABLES
        // =========================
        int windmillState = 0;
        int windmillStep = 0;

        long windmillTimer = 0;
        long windmillReturnStart = 0;

        double windmillStartPosition = WINDMILL_HOME;

        waitForStart();

        while (opModeIsActive()) {

            long now = System.currentTimeMillis();

            // =========================
            // READ BUTTONS AND TRIGGERS
            // =========================
            boolean aPressed = gamepad2.a && !previousA;
            boolean rbPressed = gamepad2.right_bumper && !previousRB;
            boolean bPressed = gamepad2.b && !previousB;

            boolean dpadLeftPressed =
                    gamepad2.dpad_left && !previousDpadLeft;

            boolean dpadRightPressed =
                    gamepad2.dpad_right && !previousDpadRight;

            boolean dpadUpPressed =
                    gamepad2.dpad_up && !previousDpadUp;

            boolean dpadDownPressed =
                    gamepad2.dpad_down && !previousDpadDown;

            boolean leftTriggerPressed = gamepad2.left_trigger > 0.5;
            boolean rightTriggerPressed = gamepad2.right_trigger > 0.5;

            // IMPORTANT:
            // Detect trigger presses BEFORE updating previous states.
            boolean rightTriggerJustPressed =
                    rightTriggerPressed && !previousRightTrigger;

            // =========================
            // UPDATE PREVIOUS BUTTON STATES
            // =========================
            previousA = gamepad2.a;
            previousRB = gamepad2.right_bumper;
            previousB = gamepad2.b;

            previousDpadLeft = gamepad2.dpad_left;
            previousDpadRight = gamepad2.dpad_right;
            previousDpadUp = gamepad2.dpad_up;
            previousDpadDown = gamepad2.dpad_down;

            previousLeftTrigger = leftTriggerPressed;
            previousRightTrigger = rightTriggerPressed;

            // =========================
            // NORMAL INTAKE TOGGLE
            // A BUTTON
            // =========================
            if (aPressed) {
                intakeOn = !intakeOn;
            }

            // =========================
            // INTAKE MOTOR CONTROL
            // LEFT TRIGGER = REVERSE
            // =========================
            if (leftTriggerPressed) {
                intakeMotor.setPower(-INTAKE_SPEED);
            } else if (intakeOn) {
                intakeMotor.setPower(INTAKE_SPEED);
            } else {
                intakeMotor.setPower(0);
            }

            // =========================
            // FLYWHEEL TOGGLE
            // RIGHT BUMPER
            // =========================
            if (rbPressed) {
                flywheelOn = !flywheelOn;
            }

            // =========================
            // DRIVETRAIN SENSITIVITY
            // D-PAD LEFT / RIGHT
            // =========================
            if (dpadLeftPressed) {
                driveSensitivity = Math.max(
                        MIN_SENSITIVITY_LEVEL,
                        driveSensitivity - 1
                );
            }

            if (dpadRightPressed) {
                driveSensitivity = Math.min(
                        MAX_SENSITIVITY_LEVEL,
                        driveSensitivity + 1
                );
            }

            double currentDrivePower =
                    BASE_POWER +
                    (driveSensitivity - START_SENSITIVITY_LEVEL)
                            * POWER_SENSITIVITY_STEP;

            // =========================
            // FLYWHEEL SENSITIVITY
            // D-PAD DOWN / UP
            // =========================
            if (dpadDownPressed) {
                flywheelSensitivity = Math.max(
                        MIN_SENSITIVITY_LEVEL,
                        flywheelSensitivity - 1
                );
            }

            if (dpadUpPressed) {
                flywheelSensitivity = Math.min(
                        MAX_SENSITIVITY_LEVEL,
                        flywheelSensitivity + 1
                );
            }

            double currentFlywheelPower =
                    BASE_FLYWHEEL_POWER +
                    (flywheelSensitivity - START_SENSITIVITY_LEVEL)
                            * FLYWHEEL_SENSITIVITY_STEP;

            flywheelMotor.setPower(
                    flywheelOn ? currentFlywheelPower : 0
            );

            // =========================
            // DRIVETRAIN
            // LEFT STICK = FORWARD/BACK
            // RIGHT STICK = TURN
            // =========================
            double drive = -gamepad2.left_stick_y;
            double turn = gamepad2.right_stick_x;

            if (Math.abs(drive) < 0.05) {
                drive = 0;
            }

            if (Math.abs(turn) < 0.05) {
                turn = 0;
            }

            drive *= currentDrivePower;
            turn *= currentDrivePower;

            double leftPower = drive + turn;
            double rightPower = drive - turn;

            double maxPower = Math.max(
                    1.0,
                    Math.max(Math.abs(leftPower), Math.abs(rightPower))
            );

            leftDrive.setPower(leftPower / maxPower);
            rightDrive.setPower(rightPower / maxPower);

            // =========================
            // FLOWER DANCE
            // B BUTTON
            // =========================
            if (bPressed && danceState == 0) {
                danceState = 1;
                danceCycles = 0;
                danceTimer = now;
            }

            if (danceState != 0 &&
                    now - danceTimer >= FLOWER_MOVE_TIME * 1000) {

                if (danceCycles < 6) {

                    if (danceCycles % 2 == 0) {
                        sideLeftServo.setPosition(
                                FLOWER_HOME + FLOWER_TRAVEL
                        );

                        sideRightServo.setPosition(
                                FLOWER_HOME - FLOWER_TRAVEL
                        );

                    } else {
                        sideLeftServo.setPosition(
                                FLOWER_HOME - FLOWER_TRAVEL
                        );

                        sideRightServo.setPosition(
                                FLOWER_HOME + FLOWER_TRAVEL
                        );
                    }

                    danceCycles++;
                    danceTimer = now;

                } else {
                    sideLeftServo.setPosition(FLOWER_HOME);
                    sideRightServo.setPosition(FLOWER_HOME);

                    danceState = 0;
                }
            }

            // =========================
            // WINDMILL START
            // RIGHT TRIGGER
            // =========================
            if (rightTriggerJustPressed && windmillState == 0) {

                windmillState = 1;
                windmillStep = 0;
                windmillTimer = now;
            }

            // =========================
            // WINDMILL: THREE 90-DEGREE STEPS
            // =========================
            if (windmillState == 1 &&
                    now - windmillTimer >= WINDMILL_STEP_WAIT * 1000) {

                if (windmillStep < 3) {

                    windmillServo.setPosition(
                            WINDMILL_HOME +
                            (windmillStep + 1) * WINDMILL_STEP
                    );

                    windmillStep++;
                    windmillTimer = now;

                } else {
                    windmillState = 2;
                    windmillTimer = now;
                }
            }

            // =========================
            // WINDMILL: PAUSE
            // =========================
            if (windmillState == 2 &&
                    now - windmillTimer >= WINDMILL_PAUSE * 1000) {

                windmillStartPosition = windmillServo.getPosition();
                windmillReturnStart = now;

                windmillState = 3;
            }

            // =========================
            // WINDMILL: SLOW RETURN
            // =========================
            if (windmillState == 3) {

                double progress = Math.min(
                        1.0,
                        (double) (now - windmillReturnStart) /
                                (WINDMILL_RETURN_TIME * 1000)
                );

                double position =
                        windmillStartPosition +
                        (WINDMILL_HOME - windmillStartPosition) * progress;

                windmillServo.setPosition(position);

                if (progress >= 1.0) {

                    windmillServo.setPosition(WINDMILL_HOME);
                    windmillState = 0;
                }
            }

            // =========================
            // TELEMETRY
            // =========================
            telemetry.addData("INTAKE", intakeOn ? "ON" : "---");

            telemetry.addData(
                    "REVERSE INTAKE",
                    leftTriggerPressed ? "ON" : "---"
            );

            telemetry.addData(
                    "FLOWER",
                    danceState != 0 ? "ON" : "---"
            );

            telemetry.addData(
                    "SPINWHEEL",
                    flywheelOn ? "ON" : "---"
            );

            telemetry.addData(
                    "WINDMILL",
                    windmillState != 0 ? "ON" : "---"
            );

            telemetry.addLine();

            telemetry.addData(
                    "DRIVE SENSITIVITY",
                    "%d / 10 (%.2f)",
                    driveSensitivity,
                    currentDrivePower
            );

            telemetry.addData(
                    "FLYWHEEL SENSITIVITY",
                    "%d / 10 (%.2f)",
                    flywheelSensitivity,
                    currentFlywheelPower
            );
            telemetry.update();

            sleep(10);
        }

        // =========================
        // STOP MOTORS
        // =========================
        leftDrive.setPower(0);
        rightDrive.setPower(0);
        flywheelMotor.setPower(0);
        intakeMotor.setPower(0);
    }
}