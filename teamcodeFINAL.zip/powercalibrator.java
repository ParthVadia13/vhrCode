
package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Spinwheel Test", group = "Testing")
public class powercalibrator extends LinearOpMode {

    // =====================================
    // EDITABLE SETTINGS
    // =====================================

    private static final double START_POWER = 0.30;

    private static final double LARGE_ADJUSTMENT = 0.05;
    private static final double SMALL_ADJUSTMENT = 0.01;

    // Windmill settings
    private static final double WINDMILL_HOME = 0.15;
    private static final double WINDMILL_STEP = 90.0 / 300.0;
    private static final double WINDMILL_STEP_WAIT = 0.50;
    private static final double WINDMILL_PAUSE = 1.00;
    private static final double WINDMILL_RETURN_TIME = 2.00;

    @Override
    public void runOpMode() {

        // =====================================
        // HARDWARE
        // =====================================

        DcMotor flywheel =
                hardwareMap.get(DcMotor.class, "flywheelMotor");

        Servo windmill =
                hardwareMap.get(Servo.class, "windmillServo");

        flywheel.setDirection(DcMotor.Direction.FORWARD);
        flywheel.setPower(0);

        windmill.setPosition(WINDMILL_HOME);

        // =====================================
        // VARIABLES
        // =====================================

        double flywheelPower = START_POWER;
        boolean flywheelOn = false;

        boolean previousBumper = false;
        boolean previousUp = false;
        boolean previousDown = false;
        boolean previousLeft = false;
        boolean previousRight = false;
        boolean previousTrigger = false;

        // Windmill states:
        // 0 = idle
        // 1 = stepping
        // 2 = waiting
        // 3 = returning

        int windmillState = 0;
        int windmillStep = 0;

        double windmillPosition = WINDMILL_HOME;
        double windmillNextTime = 0;
        double returnStartTime = 0;
        double returnStartPosition = WINDMILL_HOME;

        telemetry.addLine("Spinwheel Test Ready");
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {

            double now = getRuntime();

            // =====================================
            // FLYWHEEL POWER ADJUSTMENTS
            // =====================================

            // D-pad Up: +0.05
            if (gamepad2.dpad_up && !previousUp) {
                flywheelPower += LARGE_ADJUSTMENT;
            }

            // D-pad Down: -0.05
            if (gamepad2.dpad_down && !previousDown) {
                flywheelPower -= LARGE_ADJUSTMENT;
            }

            // D-pad Left: +0.01
            if (gamepad2.dpad_left && !previousLeft) {
                flywheelPower += SMALL_ADJUSTMENT;
            }

            // D-pad Right: -0.01
            if (gamepad2.dpad_right && !previousRight) {
                flywheelPower -= SMALL_ADJUSTMENT;
            }

            // Clamp power between 0 and 1.
            flywheelPower = Math.max(0.0,
                    Math.min(1.0, flywheelPower));

            previousUp = gamepad2.dpad_up;
            previousDown = gamepad2.dpad_down;
            previousLeft = gamepad2.dpad_left;
            previousRight = gamepad2.dpad_right;

            // =====================================
            // FLYWHEEL TOGGLE
            // =====================================

            boolean currentBumper = gamepad2.right_bumper;

            if (currentBumper && !previousBumper) {
                flywheelOn = !flywheelOn;
            }

            previousBumper = currentBumper;

            flywheel.setPower(
                    flywheelOn ? flywheelPower : 0);

            // =====================================
            // WINDMILL TRIGGER
            // =====================================

            boolean currentTrigger =
                    gamepad2.right_trigger > 0.5;

            if (currentTrigger
                    && !previousTrigger
                    && windmillState == 0) {

                windmillStep = 1;

                windmillPosition =
                        WINDMILL_HOME + WINDMILL_STEP;

                windmill.setPosition(windmillPosition);

                windmillState = 1;
                windmillNextTime =
                        now + WINDMILL_STEP_WAIT;
            }

            previousTrigger = currentTrigger;

            // =====================================
            // WINDMILL MOVEMENT
            // =====================================

            // Three 90-degree increments.
            if (windmillState == 1 && now >= windmillNextTime) {

                if (windmillStep < 3) {

                    windmillStep++;

                    windmillPosition =
                            WINDMILL_HOME
                            + windmillStep * WINDMILL_STEP;

                    windmill.setPosition(windmillPosition);

                    if (windmillStep == 3) {
                        windmillState = 2;
                        windmillNextTime =
                                now + WINDMILL_PAUSE;
                    } else {
                        windmillNextTime =
                                now + WINDMILL_STEP_WAIT;
                    }
                }
            }

            // Wait before returning.
            if (windmillState == 2 && now >= windmillNextTime) {

                returnStartPosition = windmillPosition;
                returnStartTime = now;

                windmillState = 3;
            }

            // Slowly return to home.
            if (windmillState == 3) {

                double elapsed = now - returnStartTime;
                double progress = elapsed / WINDMILL_RETURN_TIME;

                if (progress >= 1.0) {

                    windmillPosition = WINDMILL_HOME;
                    windmill.setPosition(windmillPosition);

                    windmillState = 0;

                } else {

                    windmillPosition =
                            returnStartPosition
                            + (WINDMILL_HOME - returnStartPosition)
                            * progress;

                    windmill.setPosition(windmillPosition);
                }
            }

            // =====================================
            // TELEMETRY
            // =====================================

            telemetry.addLine("SPINWHEEL TEST");

            telemetry.addData("Flywheel Power",
                    "%.2f", flywheelPower);

            telemetry.addData("Flywheel Status",
                    flywheelOn ? "ON" : "OFF");

            telemetry.addData("Applied Power",
                    "%.2f", flywheel.getPower());

            telemetry.addData("Windmill Status",
                    windmillState == 0 ? "IDLE" : "RUNNING");

            telemetry.addData("Windmill Position",
                    "%.3f", windmillPosition);

            telemetry.addLine("");
            telemetry.addLine("UP/DOWN: +/- 0.05");
            telemetry.addLine("LEFT/RIGHT: +/- 0.01");
            telemetry.addLine("RIGHT BUMPER: Flywheel Toggle");
            telemetry.addLine("RIGHT TRIGGER: Windmill");

            telemetry.update();

            sleep(10);
        }

        // =====================================
        // STOP
        // =====================================

        flywheel.setPower(0);
    }
}
